﻿namespace Traspaso
{
    partial class Registro
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Registro));
            this.guardar = new System.Windows.Forms.Button();
            this.n_pass = new System.Windows.Forms.TextBox();
            this.n_user = new System.Windows.Forms.TextBox();
            this.panel1 = new System.Windows.Forms.Panel();
            this.button1 = new System.Windows.Forms.Button();
            this.a = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.n_cerrar = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // guardar
            // 
            this.guardar.BackColor = System.Drawing.Color.Cyan;
            this.guardar.Cursor = System.Windows.Forms.Cursors.Hand;
            this.guardar.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.guardar.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Underline, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.guardar.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.guardar.Location = new System.Drawing.Point(152, 228);
            this.guardar.Name = "guardar";
            this.guardar.Size = new System.Drawing.Size(226, 38);
            this.guardar.TabIndex = 5;
            this.guardar.Text = "Registrarse";
            this.guardar.UseVisualStyleBackColor = false;
            this.guardar.Click += new System.EventHandler(this.guardar_Click);
            // 
            // n_pass
            // 
            this.n_pass.BackColor = System.Drawing.SystemColors.InfoText;
            this.n_pass.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n_pass.Font = new System.Drawing.Font("Microsoft Sans Serif", 20F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_pass.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.n_pass.Location = new System.Drawing.Point(152, 168);
            this.n_pass.Multiline = true;
            this.n_pass.Name = "n_pass";
            this.n_pass.PasswordChar = '\'';
            this.n_pass.Size = new System.Drawing.Size(226, 38);
            this.n_pass.TabIndex = 4;
            this.n_pass.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // n_user
            // 
            this.n_user.BackColor = System.Drawing.SystemColors.InfoText;
            this.n_user.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.n_user.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.n_user.ForeColor = System.Drawing.SystemColors.MenuBar;
            this.n_user.Location = new System.Drawing.Point(152, 96);
            this.n_user.Multiline = true;
            this.n_user.Name = "n_user";
            this.n_user.Size = new System.Drawing.Size(226, 38);
            this.n_user.TabIndex = 3;
            this.n_user.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // panel1
            // 
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.a);
            this.panel1.Location = new System.Drawing.Point(152, 70);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(226, 242);
            this.panel1.TabIndex = 6;
            // 
            // button1
            // 
            this.button1.BackColor = System.Drawing.SystemColors.Desktop;
            this.button1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Popup;
            this.button1.ForeColor = System.Drawing.SystemColors.ControlDarkDark;
            this.button1.Location = new System.Drawing.Point(23, 200);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(174, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "¿Ya tienes cuenta? Inicia sesión";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // a
            // 
            this.a.AutoSize = true;
            this.a.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.a.Location = new System.Drawing.Point(4, 76);
            this.a.Name = "a";
            this.a.Size = new System.Drawing.Size(64, 13);
            this.a.TabIndex = 0;
            this.a.Text = "Contraseña:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.ForeColor = System.Drawing.SystemColors.ButtonFace;
            this.label1.Location = new System.Drawing.Point(156, 78);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(46, 13);
            this.label1.TabIndex = 1;
            this.label1.Text = "Usuario:";
            // 
            // n_cerrar
            // 
            this.n_cerrar.Location = new System.Drawing.Point(478, 12);
            this.n_cerrar.Name = "n_cerrar";
            this.n_cerrar.Size = new System.Drawing.Size(24, 23);
            this.n_cerrar.TabIndex = 7;
            this.n_cerrar.Text = "X";
            this.n_cerrar.UseVisualStyleBackColor = true;
            this.n_cerrar.Click += new System.EventHandler(this.n_cerrar_Click);
            // 
            // Registro
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.ClientSize = new System.Drawing.Size(514, 297);
            this.Controls.Add(this.n_cerrar);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.guardar);
            this.Controls.Add(this.n_pass);
            this.Controls.Add(this.n_user);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximumSize = new System.Drawing.Size(530, 350);
            this.Name = "Registro";
            this.Text = "Registro";
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button guardar;
        private System.Windows.Forms.TextBox n_pass;
        private System.Windows.Forms.TextBox n_user;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label a;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Button n_cerrar;
        private System.Windows.Forms.Button button1;
    }
}