﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Layout;

namespace Traspaso
{
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
        }

        private void entrar_Click(object sender, EventArgs e)
        {
            string nombre, contraseña;
            nombre = user.Text;
            contraseña = pass.Text;
            MySqlConnection con = new MySqlConnection("Server=sql9.freemysqlhosting.net;Database=sql9607653;Uid=sql9607653;Pwd=8Wubf4hGu3;");
            try
            {
                con.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error" + ex.ToString());
                throw;
            }
            string sql = "select usuario,pass from Users where usuario = '" + nombre + " ' AND pass = '" + contraseña + "' ";
            MySqlCommand cmd = new MySqlCommand(sql, con);
            MySqlDataReader read = cmd.ExecuteReader();

            if (read.Read())
            {
                MessageBox.Show("Bienvenido " + nombre);
            }
            else
            {
                MessageBox.Show("Credenciales no válidas");
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Registro r = new Registro();
            r.Show();
            this.Hide();
        }

        private void cerrar_Click(object sender, EventArgs e)
        {
            Registro r = new Registro();
            r.Close();
            this.Close();

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Registro r = new Registro();
            r.Close();
        }
    }
}