﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Windows.Forms.Layout;


namespace Traspaso
{
    public partial class Registro : Form
    {
        public Registro()
        {
            InitializeComponent();
        }

        private void guardar_Click(object sender, EventArgs e)
        {
            MySqlConnection con = new MySqlConnection("Server=sql9.freemysqlhosting.net;Database=sql9607653;Uid=sql9607653;Pwd=8Wubf4hGu3;");
            try
            {
                con.Open();
            }
            catch (MySqlException ex)
            {
                MessageBox.Show("Error" + ex.ToString());
                throw;
            }

            if (n_pass.Text == ""&&n_user.Text == "")
            {
                string sql = "insert into Users(usuario, pass) values('error', 'error')";
                MySqlCommand cmd = new MySqlCommand(sql, con);
                try
                {
                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Escriba un usuario y contraseña");
                }
                catch (MySqlException ex) { MessageBox.Show("Error" + ex.ToString()); }
            }
            else
            {
                if (n_pass.Text == "" && n_user.Text == "")
                {
                    string sql = "DELETE FROM Users WHERE usuario = 'error' AND pass = 'error'";
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    try
                    {
                        cmd.ExecuteNonQuery();
                    }
                    catch (MySqlException ex) { MessageBox.Show("Error" + ex.ToString()); }
                }
                else
                {
                    string sql = "insert into Users (usuario,pass) values ('" + n_user.Text + "' , '" + n_pass.Text + "')";
                    MySqlCommand cmd = new MySqlCommand(sql, con);
                    try
                    {
                        cmd.ExecuteNonQuery();
                        MessageBox.Show(n_user.Text + " Ha sido registrado");
                    }
                    catch (MySqlException ex) { MessageBox.Show("Error" + ex.ToString()); }
                }
            }
            con.Close();   
        }

        private void n_cerrar_Click(object sender, EventArgs e)
        {
            Form1 form1form = new Form1();
            form1form.Show(); 
            this.Close(); 
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Form1 form1form = new Form1();
            form1form.Show();
            this.Close();
        }
    }
}


